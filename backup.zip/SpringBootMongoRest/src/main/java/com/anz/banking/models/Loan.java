package com.anz.banking.models;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="loans")
public class Loan {

		private Integer loanNo;
		private String loanType;
		private long loanAmount;
		private String startDate;
		private float interestRate;
		public Integer getLoanNo() {
			return loanNo;
		}
		public void setLoanNo(Integer loanNo) {
			this.loanNo = loanNo;
		}
		public String getLoanType() {
			return loanType;
		}
		public void setLoanType(String loanType) {
			this.loanType = loanType;
		}
		public long getLoanAmount() {
			return loanAmount;
		}
		public void setLoanAmount(long loanAmount) {
			this.loanAmount = loanAmount;
		}
		public String getStartDate() {
			return startDate;
		}
		public void setStartDate(String startDate) {
			this.startDate = startDate;
		}
		public float getInterestRate() {
			return interestRate;
		}
		public void setInterestRate(float interestRate) {
			this.interestRate = interestRate;
		}
		
		
}
