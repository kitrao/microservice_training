package com.anz.banking.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.anz.banking.models.Loan;
@Transactional
public interface LoanRepository extends MongoRepository<Loan, String> {

}
